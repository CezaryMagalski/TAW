function promocja() {
    let krotkie = document.getElementById("krotko");
    let srednie = document.getElementById("srednio");
    let poldlugie = document.getElementById("poldlugo");
    let dlugie = document.getElementById("dlugo");

    let wynik = document.getElementById("wynik");
    let cena = 0;

    if(krotkie.checked) {
        cena = 25-10;
    }

    if(srednie.checked) {
        cena = 30-10;
    }

    if(poldlugie.checked) {
        cena = 40-10;
    }

    if(dlugie.checked) {
        cena = 50-10;
    }

    wynik.innerHTML = "<p>cena promocyjna: " + cena + "</p>";
}


