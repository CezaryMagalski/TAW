<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styl6.css">
    <title>Zadania na Lipiec</title>
</head>
<body>

    <header>
    <div class="baner_1">
        <img src="logo1.png" height="140px" alt="Lipiec">
    </div>

    <div class="baner_2">
        <h1>TERMINARZ</h1>
        <p> Najbliższe zadania:
    <?php

    $serwer = 'localhost';
    $uzytkownik = 'root';
    $dbname = 'kalendarz';
    $password = '';

    $db = mysqli_connect($serwer, $uzytkownik, $password, $dbname);

    $q = 'SELECT DISTINCT wpis FROM `zadania` WHERE dataZadania BETWEEN "2020-07-01" AND "2020-07-07" and wpis <> "";';
    $r = mysqli_query($db, $q);

    $zadania = "";
    while($row = mysqli_fetch_array($r)) {
    $zadania .= $row["wpis"] . "; ";
    }

    echo $zadania;
    ?>
        </p>
    </div>

    </header>

    <main>

    <?php

    $serwer = 'localhost';
    $uzytkownik = 'root';
    $dbname = 'kalendarz';
    $password = '';

    $db = mysqli_connect($serwer, $uzytkownik, $password, $dbname);

    $q = 'SELECT dataZadania, wpis FROM `zadania` WHERE miesiac = "lipiec";';
    $r = mysqli_query($db, $q);

    $zadania = "";
    while($row = mysqli_fetch_array($r)) {
    echo '<section class="blok_glowny"
            <h6>' .$row["dataZadania"].'</h6>
            <p>'. $row["wpis"]. '</p> </section>';

    }
?>

    <div class="blok_glowny">
        <h6>1234</h6>
    </div>

    </main>
    <div class="stopka">
        <a href="sierpien.html">Terminarz na Sierpien</a>
        <p>Strone wykonał: Czarek Magalski</p>
    </div>

    
</body>
</html>