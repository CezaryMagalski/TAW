<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styl.css">
    <title>Motocykle</title>
</head>
<body>
    <img src="motor.png" alt="motocykl" id="motur">

    <div class="baner">
        <h1>Motocykle - moja pasja</h1>
    </div>

    <div class="lewy">
        <h2>Gdzie pojechać?</h2>
        <dl>

        <?php

        $serwer = "localhost";
        $uzytkownik = "root";
        $haslo = "";
        $baza = "motor";

        $db = mysqli_connect($serwer, $uzytkownik, $haslo, $baza);

        $q = "SELECT nazwa, opis, poczatek, zrodlo FROM `wycieczki` JOIN zdjecia ON wycieczki.zdjecia_id = zdjecia.id;";

        $result = mysqli_query($db, $q);


        while($row = mysqli_fetch_array($result)){
            echo '<dt>'.$row['nazwa'].'rozpoczyna sie w '.$row['poczatek'].'<a href="'.$row['zrodlo'].'.jpg"> Zobacz zdjecie</a></dt>';
            echo '<dd>'.$row['opis'].'</dd>';
        }

        ?>

        </dl>
        
    </div>

    <div class="prawy1">
        <h2>Gdzie pojechać?</h2>
        <dl>
            <li>Honda CBR125R</li>
            <li>Yamaha YBR125</li>
            <li>Honda VFR800i</li>
            <li>Honda CBR1100XX</li>
            <li>BMW R1200GS LC</li>
        </dl>
    </div>

    <div class="prawy2">
        <h2>Statystyka</h2>
        <?php

        $q = "SELECT COUNT(*) AS ilosc FROM `wycieczki`;";

        $result = mysqli_query($db, $q);

        while($row = mysqli_fetch_array($result)){
            echo '<p>Wpisanych wycieczek: '.$row['ilosc'].'</p>';
        }

        ?>
        <p>Użytkowników forum: 200</p>
        <p>Przesłanych zdjęć: 1300</p>
    </div>
    
    <div class="stopka">
        <p>Strone wykonał: Czarek Magalski 3a</p>
    </div>
    
</body>
</html>