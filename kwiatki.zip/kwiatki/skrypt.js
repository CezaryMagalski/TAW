function blok1(pole) {

    var pole1 = document.getElementById("blok1");
    var pole2 = document.getElementById("blok2");
    var pole3 = document.getElementById("blok3");

    let imie = document.getElementById("imie").value;
    let nazwisko = document.getElementById("nazwisko").value;

    if(pole==='pole1'){

        pole1.style.visibility = "hidden";
        pole2.style.visibility = "visible";
    }
    
    console.log("Witaj," , imie, nazwisko);
}

function blok2(pole) {

    var pole1 = document.getElementById("blok1");
    var pole2 = document.getElementById("blok2");
    var pole3 = document.getElementById("blok3");

    if(pole==='pole2'){
        
        pole2.style.visibility = "hidden";
        pole3.style.visibility = "visible";
    }
}

function zlehaslo() {
    
    var haslo1 = document.getElementById("haslo1").value;
    var haslo2 = document.getElementById("haslo2").value;

    if(haslo1!==haslo2){
        alert("Podane Hasła różnią się");
    }
}