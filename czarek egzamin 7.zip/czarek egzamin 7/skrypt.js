function obliczsume() {
    let peeling = document.getElementById("peeling");

    let maska = document.getElementById("maska");

    let masaz = document.getElementById("masaz");
    
    let makijaz = document.getElementById("makijaz");
    
    let wynik = document.getElementById("wynik");
    let suma = 0;

    if(peeling.checked) {
        suma = suma + 45;
    }

    if(maska.checked) {
        suma = suma + 30;
    }

    if(masaz.checked) {
        suma = suma + 20;
    }

    if(makijaz.checked) {
        suma = suma + 50;
    }

    wynik.innerHTML = "<p>Cena to: " + suma + "zł</p>";
}

