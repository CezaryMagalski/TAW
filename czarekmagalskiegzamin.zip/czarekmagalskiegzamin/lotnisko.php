<!DOCTYPE html>
<?php
setcookie("user", "test", time() + 7200, '/');
?>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styl5.css">
    <title>Port Lotniczy</title>
</head>
<body>

    <div class="baner1">
        <img src="zad5przesklanowame.png" alt="logo lotnisko">
    </div>
    
    <div class="baner2">
        <h1>Przyloty</h1>
    </div>

    <div class="baner3">
        <h3>przydatne linki</h3>
        <a href="kwerendy.txt">Pobierz</a>
    </div>

    <div class="blokglowny">
        <table>
        <tr>
            <th>czas</th>
            <th>kierunek</th>
            <th>numer rejsu</th>
            <th>status</th>
        </tr>
        <?php

        $uzytkownik = "root";
        $haslo = "";
        $baza = "egzaminloty";
        $serwer  = "localhost";

        $polaczenie = mysqli_connect($serwer, $uzytkownik, $haslo, $baza);

        $q = 'SELECT czas, kierunek, nr_rejsu, status_lotu FROM `odloty` ORDER by czas;';

        $result = mysqli_query($polaczenie, $q);

           while($row = mysqli_fetch_array($result)){
            echo  '<tr>';

            echo '<td>'.$row ['czas'].'</td>';
            echo '<td>'.$row ['kierunek'].'</td>';
            echo '<td>'.$row ['nr_rejsu'].'</td>';
            echo '<td>'.$row ['status_lotu'].'</td>';

            echo  '</tr>';

           }

        ?>
        </table>
    </div>

    <div class="stopka1">
        <?php

           if(!isset($_COOKIE["user"])){
            echo "<p><b>Dzień dobry strona używa ciasteczek</b></p>";
           } else {
            echo "<p><i>Dzień dobry, witaj ponownie na stronie lotniska</i></p>";
            }
           
        ?>
    </div>

    <div class="stopka2">
        <p>Autor: Czarek Magalski 3a</p>
    </div>
    
</body>
</html>